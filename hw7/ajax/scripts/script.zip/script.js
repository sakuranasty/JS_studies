window.onload=function(){
  var req=new XMLHttpRequest();
  req.open('GET','https://openweathermap.org/data/2.5/weather?id=2643743&appid=b6907d289e10d714a6e88b30761fae22&units=imperial',true);
  req.send();
  // req.onreadystatechange = function() { 
  //     if (req.readyState != 4) return;
  // };
  
  if (req.status != 200) {
      alert(req.status + ': ' + req.statusText);
    } else {
      document.getElementsByTagName(wrap)[0].appendChild(req.responseText);
    }

};